<?php
	$servidor = 'ederton.com.br';
	$name = 'preview/amj-audios';
	$url_base = $servidor . '/' . $name;

	$usuario = '';
	$senha = '';
	$db = '';
?>