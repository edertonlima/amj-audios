<?php
	
	$servidor = 'ederton.com.br/preview';
	$projeto = 'amj-audios';

	$url_base = $servidor . '/' . $projeto;
	$url_admin = $servidor . '/' . $projeto . '/admin';

?>