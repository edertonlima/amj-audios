<h3>Menu</h3>

<nav class="nav nav-admin">
	<ul>
		<li>
			<a href="post.php" class="menu-area">
				<i class="fas fa-microphone-alt"></i> Áudios
			</a>
			<ul class="submenu">
				<li>
					<a href="post-new.php">Novo Áudio</a>
				</li>

				<?php /*<li>
					<a href="">Assuntos</a>
				</li>*/?>
			</ul>
		</li>
	</ul>
</nav>